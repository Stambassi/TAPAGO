//
//  Projeto_finalApp.swift
//  Projeto_final
//
//  Created by Turma02-25 on 04/04/25.
//

import SwiftUI

@main
struct Projeto_finalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
