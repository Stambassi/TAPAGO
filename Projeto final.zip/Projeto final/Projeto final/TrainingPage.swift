//
//  TrainingPage.swift
//  Projeto final
//
//  Created by Turma02-25 on 04/04/25.
//

import SwiftUI
import UIKit

struct TrainingPage: View {
    
    var body: some View {
        Text("AAAAAA")
    }
}

#Preview {
    TrainingPage()
}
